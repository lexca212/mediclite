$( function() {
  $('.tanggal').datepicker({
    dateFormat: 'yy-mm-dd'
  });
} );
