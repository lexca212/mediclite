<?php

namespace Plugins\Kunjungan_Ralan;

use Systems\AdminModule;

class Admin extends AdminModule
{

    public function navigation()
    {
        return [
            'Kelola'   => 'manage',
        ];
    }

    public function anyManage()
    {
        $tgl_kunjungan = date('Y-m-d');
        $tgl_kunjungan_akhir = date('Y-m-d');
        $status_periksa = '';
        

        if (isset($_POST['periode_rawat_jalan'])) {
            $tgl_kunjungan = $_POST['periode_rawat_jalan'];
        }
        if (isset($_POST['periode_rawat_jalan_akhir'])) {
            $tgl_kunjungan_akhir = $_POST['periode_rawat_jalan_akhir'];
        }
        if (isset($_POST['status_periksa'])) {
            $status_periksa = $_POST['status_periksa'];
        }
        // $cek_vclaim = $this->db('mlite_modules')->where('dir', 'vclaim')->oneArray();
        $this->_Display($tgl_kunjungan, $tgl_kunjungan_akhir, $status_periksa);
        return $this->draw('manage.html', [
            'poli'  => $this->db('poliklinik')->where('status', '1')->toArray(),
            'rawat_jalan' => $this->assign
        ]);
    }

    public function anyDisplay()
    {
        $tgl_kunjungan = date('Y-m-d');
        $tgl_kunjungan_akhir = date('Y-m-d');
        $status_periksa = '';

        if (isset($_POST['periode_rawat_jalan'])) {
            $tgl_kunjungan = $_POST['periode_rawat_jalan'];
        }
        if (isset($_POST['periode_rawat_jalan_akhir'])) {
            $tgl_kunjungan_akhir = $_POST['periode_rawat_jalan_akhir'];
        }
        if (isset($_POST['status_periksa'])) {
            $status_periksa = $_POST['status_periksa'];
        }
        // if (isset($_POST['poli'])) {
        //     $poli = $_POST['poli'];
        // }
        //$cek_vclaim = $this->db('mlite_modules')->where('dir', 'vclaim')->oneArray();
        $this->_Display($tgl_kunjungan, $tgl_kunjungan_akhir, $status_periksa);
        echo $this->draw('display.html', [
            'rawat_jalan' => $this->assign
        ]);
        exit();
    }

    public function _Display($tgl_kunjungan, $tgl_kunjungan_akhir, $status_periksa = '')
    {
        $this->_addHeaderFiles();

        if (isset($_POST['poli'])) {
            $poli = $_POST['poli'];
        }
        $this->assign['poliklinik']     = $this->db('poliklinik')->where('status', '1')->toArray();
        $this->assign['dokter']         = $this->db('dokter')->where('status', '1')->toArray();
        $this->assign['penjab']       = $this->db('penjab')->where('status', '1')->toArray();
        $this->assign['no_rawat'] = '';
        $this->assign['no_reg']     = '';
        $this->assign['tgl_registrasi'] = date('Y-m-d');
        $this->assign['jam_reg'] = date('H:i:s');

        // $sql = "SELECT reg_periksa.*,
        //     pasien.*,
        //     dokter.*,
        //     poliklinik.*,
        //     penjab.*
        //   FROM reg_periksa, pasien, dokter, poliklinik, penjab
        //   WHERE reg_periksa.no_rkm_medis = pasien.no_rkm_medis
        //   AND reg_periksa.tgl_registrasi BETWEEN '$tgl_kunjungan' AND '$tgl_kunjungan_akhir'
        //   AND reg_periksa.kd_dokter = dokter.kd_dokter
        //   AND reg_periksa.stts != 'Batal'
        //   AND reg_periksa.kd_poli = poliklinik.kd_poli
        //   AND reg_periksa.kd_pj = penjab.kd_pj";
        $sql = "
SELECT 
  reg_periksa.*,
  pasien.*,
  poliklinik.*,
  penjab.*,
  kecamatan.nm_kec,
  dokter.nm_dokter AS dokter_pemeriksa,
  dokter_dpjp.nm_dokter AS dokter_dpjp
FROM reg_periksa
JOIN pasien ON reg_periksa.no_rkm_medis = pasien.no_rkm_medis
JOIN dokter ON reg_periksa.kd_dokter = dokter.kd_dokter
JOIN poliklinik ON reg_periksa.kd_poli = poliklinik.kd_poli
JOIN penjab ON reg_periksa.kd_pj = penjab.kd_pj
LEFT JOIN dpjp_ranap AS dpjp ON reg_periksa.no_rawat = dpjp.no_rawat
LEFT JOIN dokter AS dokter_dpjp ON dpjp.kd_dokter = dokter_dpjp.kd_dokter
LEFT JOIN kecamatan ON pasien.kd_kec = kecamatan.kd_kec
WHERE reg_periksa.tgl_registrasi BETWEEN '$tgl_kunjungan' AND '$tgl_kunjungan_akhir'
  AND reg_periksa.stts != 'Batal'
";




        // if($status_periksa == 'belum') {
        //   $sql .= " AND reg_periksa.stts = 'Belum'";
        // }
        // if($status_periksa == 'selesai') {
        //   $sql .= " AND reg_periksa.stts = 'Sudah'";
        // }
        // if($status_periksa == 'lunas') {
        //   $sql .= " AND reg_periksa.status_bayar = 'Sudah Bayar'";
        // }

        if ($status_periksa == 'Ralan') {
            $sql .= " AND reg_periksa.status_lanjut = 'Ralan'";
        }
        if ($status_periksa == 'Ranap') {
            $sql .= " AND reg_periksa.status_lanjut = 'Ranap'";
        }
        if (!empty($_POST['poli'])) {
            // Jika user memilih poli tertentu
            $poli = $_POST['poli'];
            $sql .= " AND reg_periksa.kd_poli = '$poli'";
        } else {
            // Jika user tidak memilih apa pun (kosong)
            $sql .= " AND reg_periksa.kd_poli != ''";
        }

        // if($status_periksa == 'lunas') {
        //   $sql .= " AND reg_periksa.status_bayar = 'Sudah Bayar'";
        // }

        $stmt = $this->db()->pdo()->prepare($sql);
        $stmt->execute();
        $rows = $stmt->fetchAll();

        $this->assign['list'] = [];
        foreach ($rows as $row) {
            $this->assign['list'][] = $row;
        }
    //     $chartSql = "
    //     SELECT poliklinik.nm_poli AS poli, COUNT(*) AS total
    //     FROM reg_periksa
    //     JOIN poliklinik ON reg_periksa.kd_poli = poliklinik.kd_poli
    //     WHERE reg_periksa.tgl_registrasi BETWEEN '$tgl_kunjungan' AND '$tgl_kunjungan_akhir'
    //     GROUP BY poliklinik.nm_poli
    //     ORDER BY total DESC
    // ";
    //     $chartStmt = $this->db()->pdo()->prepare($chartSql);
    //     $chartStmt->execute();
    //     $chartData = $chartStmt->fetchAll(\PDO::FETCH_ASSOC);

        // kirim ke template (Smarty)
        // $this->assign['chart_labels'] = array_column($chartData, 'poli');
        // $this->assign['chart_values'] = array_column($chartData, 'total');
    }

    public function getPoli()
    {
        $this->db('poliklinik')->where('status', '1')->toArray();
    }

    public function getJavascript()
    {
        header('Content-type: text/javascript');
        $this->assign['websocket'] = $this->settings->get('settings.websocket');
        $this->assign['websocket_proxy'] = $this->settings->get('settings.websocket_proxy');
        echo $this->draw(MODULES . '/kunjungan_ralan/js/admin/kunjungan_ralan.js', ['mlite' => $this->assign]);
        exit();
    }
    private function _addHeaderFiles()
    {
        $this->core->addCSS(url('assets/css/dataTables.bootstrap.min.css'));
        $this->core->addJS(url('assets/jscripts/jquery.dataTables.min.js'));
        $this->core->addJS(url('assets/jscripts/dataTables.bootstrap.min.js'));
        $this->core->addCSS(url('assets/css/bootstrap-datetimepicker.css'));
        $this->core->addJS(url('assets/jscripts/moment-with-locales.js'));
        $this->core->addJS(url('assets/jscripts/bootstrap-datetimepicker.js'));
        $this->core->addJS(url([ADMIN, 'kunjungan_ralan', 'javascript']), 'footer');
    }
}
