<?php

    return [
        'name'          =>  'Data Analys',
        'description'   =>  'Modul Kunjungan BOR untuk mLITE',
        'author'        =>  'Lexca',
        'version'       =>  '1.0',
        'compatibility' =>  '4.*.*',
        'icon'          =>  'bar-chart',
        'install'       =>  function () use ($core) {
        },
        'uninstall'     =>  function() use($core)
        {
        }
    ];
