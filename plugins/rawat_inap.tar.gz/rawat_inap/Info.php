<?php

return [
    'name'          =>  'Rawat Inap',
    'description'   =>  'Modul rawat inap untuk mLITE',
    'author'        =>  'Basoro',
    'version'       =>  '1.0',
    'compatibility' =>  '4.*.*',
    'icon'          =>  'hotel',
    'install'       =>  function () use ($core) {
    },
    'uninstall'     =>  function() use($core)
    {
    }
];
